#include<stdio.h>
#include<string.h>

#ifndef MaxText 
#define MaxText 500
#endif

char * delSpaceBeforeEnd(char * str);

char * readInMyWay();
