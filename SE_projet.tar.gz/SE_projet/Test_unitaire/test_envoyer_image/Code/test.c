#include<stdio.h>
int main(){
    char c=EOF;
    printf ("c is %c\n",c);
    return 0;
}
