#include<stdio.h>
#include<string.h>

#include"CreatBankImage.h"

#ifndef MAXSIZEOFSET
#define MAXSIZEOFSET 100
#endif

#ifndef MINISIZE
#define MINSIZE -1
#endif

#ifndef MAXSIZE
#define MAXSIZE 100000000
#endif
