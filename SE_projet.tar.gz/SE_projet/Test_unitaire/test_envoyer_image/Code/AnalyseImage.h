#include<stdio.h>
#include<string.h>

#include"targa_image.h"

int histogramme(const char * imageName,int * his,int m,int n);
